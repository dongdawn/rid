import numpy as np

ffs = np.loadtxt('force.out')
ffs_magnitude = np.mean(ffs**2)**0.5
diff = ffs[0,:] - ffs[3,:]
print("relative diff of KAPPA=500, dt=0.5fs from KAPPA=1000,dt=0.5fs: %.4lf"%(np.mean(diff**2)**0.5/ffs_magnitude))
diff = ffs[1,:] - ffs[3,:]
print("relative diff of KAPPA=500, dt=1.0fs from KAPPA=1000,dt=0.5fs: %.4lf"%(np.mean(diff**2)**0.5/ffs_magnitude))
diff = ffs[2,:] - ffs[3,:]
print("relative diff of KAPPA=500, dt=2.0fs from KAPPA=1000,dt=0.5fs: %.4lf"%(np.mean(diff**2)**0.5/ffs_magnitude))
diff = ffs[4,:] - ffs[3,:]
print("relative diff of KAPPA=1000, dt=1.0fs from KAPPA=1000,dt=0.5fs: %.4lf"%(np.mean(diff**2)**0.5/ffs_magnitude))
diff = ffs[5,:] - ffs[3,:]
print("relative diff of KAPPA=1000, dt=2.0fs from KAPPA=1000,dt=0.5fs: %.4lf"%(np.mean(diff**2)**0.5/ffs_magnitude))
