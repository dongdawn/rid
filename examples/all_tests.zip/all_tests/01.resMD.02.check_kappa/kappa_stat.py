import numpy as np

ffs = np.loadtxt('force.out')
ffs_magnitude = np.mean(ffs**2)**0.5

diff = ffs[0,:] - ffs[-1,:]
print("relative diff of KAPPA=50 from KAPPA=1000: %.4lf"%(np.mean(diff**2)**0.5/ffs_magnitude))
diff = ffs[1,:] - ffs[-1,:]
print("relative diff of KAPPA=100 from KAPPA=1000: %.4lf"%(np.mean(diff**2)**0.5/ffs_magnitude))
diff = ffs[2,:] - ffs[-1,:]
print("relative diff of KAPPA=200 from KAPPA=1000: %.4lf"%(np.mean(diff**2)**0.5/ffs_magnitude))
diff = ffs[3,:] - ffs[-1,:]
print("relative diff of KAPPA=500 from KAPPA=1000: %.4lf"%(np.mean(diff**2)**0.5/ffs_magnitude))
diff = ffs[-3,:] - ffs[-2,:]
print("relative diff of KAPPA=200 from KAPPA=500: %.4lf"%(np.mean(diff**2)**0.5/ffs_magnitude))
