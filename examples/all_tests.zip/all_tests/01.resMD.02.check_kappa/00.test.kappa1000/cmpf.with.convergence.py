#!/usr/bin/env python3

import numpy as np
import subprocess as sp

tail=0.0
cv_dih_dim = 38
data = np.loadtxt ("plm.res.out")
data = data[:,1:]

mk_kappa_cmd = "grep KAPPA plumed.res.dat  | awk '{print $4}' | cut -d '=' -f 2 > kappa.out"
sp.check_call (mk_kappa_cmd, shell = True)

kk=np.loadtxt('kappa.out'); 
cc=np.loadtxt('centers.out'); 

nframes=data.shape[0]
ndih_values=data.shape[1]
if cv_dih_dim is not None :
    ndih_values = cv_dih_dim

for ii in range (1, nframes) :
    for jj in range (ndih_values) :
        if   data[ii,jj] - data[0,jj] >= np.pi :
            data[ii,jj] -= np.pi * 2.
        elif data[ii,jj] - data[0,jj] < -np.pi :
            data[ii,jj] += np.pi * 2.

n_10ps_block = 1000   # since we have 10ns data, we have 1000 10ps blocks.
nstep_10ps = nframes // n_10ps_block   # each 10ps contains nsteps.

avgins = np.average (np.reshape(data[:n_10ps_block*nstep_10ps,:],[n_10ps_block,nstep_10ps,-1]), axis = 1)
avgins = np.mod(avgins - np.reshape(cc,[1,-1]) + np.pi * 5., np.pi * 2.) - np.pi
ffs = avgins * np.reshape(kk,[1,-1]) #shape 1000 * 38
ff_mean = np.mean(ffs,axis=0)
ff_magnitude = np.mean(ff_mean**2)**0.5

print("relative stat error of 10ps mdrun: %.4lf"%(np.mean(np.std(ffs,axis=0))/ff_magnitude))
ffs_tmp = np.mean(np.reshape(ffs,[500,2,-1]), axis=1)
print("relative stat error of 20ps mdrun: %.4lf"%(np.mean(np.std(ffs_tmp,axis=0))/ff_magnitude))
ffs_tmp = np.mean(np.reshape(ffs,[200,5,-1]), axis=1)
print("relative stat error of 50ps mdrun: %.4lf"%(np.mean(np.std(ffs_tmp,axis=0))/ff_magnitude))
ffs_tmp = np.mean(np.reshape(ffs,[100,10,-1]), axis=1)
print("relative stat error of 100ps mdrun: %.4lf"%(np.mean(np.std(ffs_tmp,axis=0))/ff_magnitude))
ffs_tmp = np.mean(np.reshape(ffs,[50,20,-1]), axis=1)
print("relative stat error of 200ps mdrun: %.4lf"%(np.mean(np.std(ffs_tmp,axis=0))/ff_magnitude))
ffs_tmp = np.mean(np.reshape(ffs,[20,50,-1]), axis=1)
print("relative stat error of 500ps mdrun: %.4lf"%(np.mean(np.std(ffs_tmp,axis=0))/ff_magnitude))
ffs_tmp = np.mean(np.reshape(ffs,[10,100,-1]), axis=1)
print("relative stat error of 1ns mdrun: %.4lf"%(np.mean(np.std(ffs_tmp,axis=0))/ff_magnitude))
ffs_tmp = np.mean(np.reshape(ffs,[5,200,-1]), axis=1)
print("relative stat error of 2ns mdrun: %.4lf"%(np.mean(np.std(ffs_tmp,axis=0))/ff_magnitude))
