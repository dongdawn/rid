#!/bin/bash

grocleanit

rm -f ang*.xvg
rm -f \#*
rm -f *out
rm -f equi.gro
rm -f equiout.mdp
rm -f plumed.res.dat
