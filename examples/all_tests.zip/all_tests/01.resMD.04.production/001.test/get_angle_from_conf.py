import mdtraj as md
import numpy as np

filename='conf.gro'
filendx='angle.ndx'
ndx=np.loadtxt(filendx,skiprows=1)
t=md.load(filename,top=filename)
dihedrals=md.compute_dihedrals(t,ndx)
np.savetxt('centers.dat',np.reshape(dihedrals,[1,-1]))
